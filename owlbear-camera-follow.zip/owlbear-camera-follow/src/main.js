import OBR from "https://esm.sh/@owlbear-rodeo/sdk@3";
import "./style.css";

const ID = "com.custom.camera-follow";
const KEY = `${ID}/metadata`;

const app = document.querySelector("#app");

function esc(s = "") {
  return s.replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));
}

async function getCharacters() {
  if (!(await OBR.scene.isReady())) return [];
  return OBR.scene.items.getItems(item => item.layer === "CHARACTER" && item.visible !== false);
}

async function render() {
  const meta = await OBR.player.getMetadata();
  const state = meta[KEY] || {};
  const chars = await getCharacters();
  const target = chars.find(c => c.id === state.targetId);
  const selected = await OBR.player.getSelection();
  const selectedId = selected?.[0];

  app.innerHTML = `
    <div class="wrap">
      <h2>🎥 Camera Follow</h2>
      <p class="sub">A câmera acompanha seu personagem enquanto ele anda.</p>

      <label class="toggle">
        <input id="enabled" type="checkbox" ${state.enabled ? "checked" : ""}>
        <span></span>
        <b>Seguir personagem</b>
      </label>

      <div class="card">
        <div class="label">Personagem seguido</div>
        <div class="target">${target ? esc(target.name || "Personagem sem nome") : "Nenhum personagem escolhido"}</div>
        <select id="character">
          <option value="">— Escolher personagem —</option>
          ${chars.map(c => `<option value="${esc(c.id)}" ${c.id === state.targetId ? "selected" : ""}>${esc(c.name || "Personagem sem nome")}</option>`).join("")}
        </select>
        <button id="useSelected" ${selectedId && chars.some(c => c.id === selectedId) ? "" : "disabled"}>Usar personagem selecionado</button>
      </div>

      <div class="card">
        <div class="label">Modo de câmera</div>
        <select id="mode">
          <option value="soft" ${state.mode !== "hard" ? "selected" : ""}>Suave — recomendado</option>
          <option value="hard" ${state.mode === "hard" ? "selected" : ""}>Travada — acompanha imediatamente</option>
        </select>
      </div>

      <button class="refresh" id="refresh">↻ Atualizar personagens</button>
      <div class="hint">Dica: selecione um token de personagem no Owlbear e clique em “Usar personagem selecionado”.</div>
    </div>`;

  document.querySelector("#enabled").addEventListener("change", async e => {
    await OBR.player.setMetadata({ [KEY]: { ...state, enabled: e.target.checked } });
  });

  document.querySelector("#mode").addEventListener("change", async e => {
    await OBR.player.setMetadata({ [KEY]: { ...state, mode: e.target.value } });
  });

  document.querySelector("#character").addEventListener("change", async e => {
    if (!e.target.value) return;
    const item = chars.find(c => c.id === e.target.value);
    if (!item) return;
    await OBR.player.setMetadata({ [KEY]: { ...state, targetId: item.id, enabled: true } });
    await OBR.viewport.animateTo({ position: item.position, scale: await OBR.viewport.getScale() });
    render();
  });

  document.querySelector("#useSelected").addEventListener("click", async () => {
    if (!selectedId) return;
    const item = chars.find(c => c.id === selectedId);
    if (!item) return;
    await OBR.player.setMetadata({ [KEY]: { ...state, targetId: item.id, enabled: true } });
    await OBR.viewport.animateTo({ position: item.position, scale: await OBR.viewport.getScale() });
    render();
  });

  document.querySelector("#refresh").addEventListener("click", render);
}

async function startFollow() {
  let target = null;
  let enabled = false;
  let mode = "soft";
  let raf = 0;
  let lastMove = 0;

  async function updateState() {
    const meta = await OBR.player.getMetadata();
    const s = meta[KEY] || {};
    enabled = !!s.enabled;
    mode = s.mode || "soft";
    target = s.targetId || null;
  }

  async function tick(now) {
    if (enabled && target && now - lastMove > 28) {
      const items = await OBR.scene.items.getItems([target]);
      const item = items[0];
      if (item && item.visible !== false) {
        const scale = await OBR.viewport.getScale();
        if (mode === "hard") {
          await OBR.viewport.setPosition(item.position);
        } else {
          const current = await OBR.viewport.getPosition();
          const t = 0.28;
          const next = {
            x: current.x + (item.position.x - current.x) * t,
            y: current.y + (item.position.y - current.y) * t
          };
          await OBR.viewport.setPosition(next);
        }
        lastMove = now;
      }
    }
    raf = requestAnimationFrame(tick);
  }

  OBR.player.onChange(() => updateState());
  OBR.scene.onReadyChange(async ready => { if (ready) await updateState(); });
  await updateState();
  requestAnimationFrame(tick);
}

OBR.onReady(async () => {
  await render();
  await startFollow();
  OBR.scene.items.onChange(() => {});
});
